#include "stdio.h"
#define exa
#ifdef ex1


/*2 - Com a estrutura abaixo, defina um vetor de estruturas de 4 elementos.
    Receba os dados pelo teclado usando ponteiros e imprima-os no video
    tamb�m usando ponteiros. Utilize um comando de loop. (vetor de estruturas)
              nome, end, cidade, estado, cep */
struct reg{
    char no[20];
    char end[20];
    char cid[20];
    char es[3];
    char cep[10];
};

main(){
struct reg c[4], *p;
int x;
int op;

p = &c[0];

for(;;){
    printf("1 - entra dados\n");
    printf("2 - lista dados\n");
    printf("3 - sair\n");
    scanf("%d",&op);
    getchar();
 if(op == 3)
        break;

    switch(op){
        case 1 :
for(x=0;x<2;x++){
    printf("digite o nome:");
    gets((p+x) -> no);
    printf("digite o endereco:");
    gets((p+x)->end);
    printf("digite o cidade:");
    gets((p+x)->cid);
    printf("digite o estado:");
    gets((p+x)->es);
    printf("digite o cep:");
    gets((p+x)->cep);
    printf("\n");
}
   break;
    case 2 :
for(x=0;x<2;x++){
    printf("\n o nome: %s\n",(p+x)->no);
    printf(" o endereco: %s\n",(p+x)->end);
    printf(" o cidade: %s\n",(p+x)->cid);
    printf(" o estado: %s\n",(p+x)->es);
    printf(" o cep: %s\n",(p+x)->cep);
}
break;
   }
}
}
#endif // ex1
/*4 - Receba 2 string de ate 10 caracteres via teclado, compare-as usando ponteiros
    e mostre como resultado se s�o IGUAIS ou DIFERENTES. */
    /*
main(){
char nom1[11], *p1;
char nom2[11], *p2;
int x;
p1 = &nom1[0];
p2 = &nom2[0];

for(;;){
printf("digite nome1:");
gets(p1);

if( *(p1 + 0) == '\0')   //com scanf n�o funciona
    break;
printf("digite nome2:");
gets(p2);

printf("os n. sao %s  %s\n",p1,p2);

for(x=0;*(p1 + x) != '\0';x++)
    if(*(p1 + x) != *(p2 + x))
        break;
if(*(p1 + x) == '\0' && *(p2 + x) == '\0')
    printf("iguais\n");
else
    printf("diferente\n");
}
}*/
#ifdef exa
/*6 - Acrescente ao menu do exercicio anterior as funcoes de procura, altera e
    exclui um registro. */
struct reg{
    char no[20];
    char end[20];
    char cid[20];
    char es[3];
    char cep[10];
};

main(){
struct reg c[4], *p;
int x;
int op;

p = &c[0];

read(p);

for(;;){
    printf("1 - entra dados\n");
    printf("2 - lista dados\n");
    printf("3 - comp dados\n");
    printf("4 - altera dados\n");
    printf("5 - exclui dados\n");
    printf("6 - sair\n");
    scanf("%d",&op);
    getchar();
 if(op == 6)
        break;

    switch(op){
        case 1 :
            entra(p);
            break;
        case 2 :
            imp(p);
            break;
        case 3 :
            x = comp(p);
            if(x != -1)
                printf("iguais\n");
            else
                printf("diferentes\n");
            break;
        case 4 :
            altera(p);
            break;
         case 5 :
            exclui(p);
            break;
   }
}
}

entra(struct reg *p)
{
    int x;
    for(x=0;x<2;x++){
    printf("digite o nome:");
    gets((p+x) -> no);
    printf("digite o endereco:");
    gets((p+x)->end);
    printf("digite o cidade:");
    gets((p+x)->cid);
    printf("digite o estado:");
    gets((p+x)->es);
    printf("digite o cep:");
    gets((p+x)->cep);
    printf("\n");

}
    save(p);
}
imp(struct reg *p)
{
    int x;
    for(x=0;x<2;x++){
    printf("\n o nome: %s\n",(p+x)->no);
    printf(" o endereco: %s\n",(p+x)->end);
    printf(" o cidade: %s\n",(p+x)->cid);
    printf(" o estado: %s\n",(p+x)->es);
    printf(" o cep: %s\n",(p+x)->cep);
}
}

comp(struct reg *p)
{
char nome1[20], *p1;
int x,y;
p1=nome1;

printf("digite nome1:");
scanf("%s",p1);
//printf("%s\n",p1);

for(y=0;y<2;y++){
    //printf("for %s  %s\n",p1 , (p + y)->no);
for(x=0;*(p1 + x) != '\0';x++){
    //printf("dentro %c  %c\n",*(p1 + x) , (p + y)->no[x]);
    if(*(p1 + x) != (p + y)->no[x])
        break;

}

//printf("fora %c  %c\n",*(p1 + x) , (p + y)->no[x]);
if(*(p1 + x) == '\0' && (p + y)->no[x] == '\0'){
    //printf("iguais\n");
    //break;
    return y;
}
//else
    //printf("diferente\n");

}
return -1;
}
altera(struct reg *p){
    int x;
    x = comp(p);
    if(x == -1){
        printf("nao existe\n");
        return;
    }
    getchar();
     printf("digite o nome:");
    gets((p+x) -> no);
    printf("digite o endereco:");
    gets((p+x)->end);
    printf("digite o cidade:");
    gets((p+x)->cid);
    printf("digite o estado:");
    gets((p+x)->es);
    printf("digite o cep:");
    gets((p+x)->cep);
    printf("\n");
    save(p);
}

exclui(struct reg *p){
    int x;
    x = comp(p);
    if(x == -1){
        printf("nao existe\n");
        return;
    }
    getchar();
    printf("apaga registro!\n");
    printf("nome e': %s\n",(p+x) -> no);
    (p+x) -> no[0] = '*';
    save(p);

}
save(struct reg *p)
{
    int x;
    struct reg temp;
    FILE *pa;

    pa=fopen("cad","w");
    for(x=0;x<2;x++){
    printf("\n o nome: %s\n",(p+x)->no);
    printf(" o endereco: %s\n",(p+x)->end);
    printf(" o cidade: %s\n",(p+x)->cid);
    printf(" o estado: %s\n",(p+x)->es);
    printf(" o cep: %s\n",(p+x)->cep);
        fwrite((p+x),sizeof(temp),1,pa);
    }
    fclose(pa);
}

read(struct reg *p)
{
    int x;
    struct reg temp;
    FILE *pa;
    pa=fopen("cad","r");
    for(x=0;x<2;x++){
        fread((p+x),sizeof(temp),1,pa);
    }
    fclose(pa);
}
#endif // ex2
